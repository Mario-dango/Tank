#ifndef XMLRPC_CURL_TRANSPORT_H
#define XMLRPC_CURL_TRANSPORT_H

#include "xmlrpc_transport.h"

extern struct clientTransportOps xmlrpc_curl_transport_ops;

#endif
